<?php
// index.php

header("Location: AUTH/login.php");
exit;
?>