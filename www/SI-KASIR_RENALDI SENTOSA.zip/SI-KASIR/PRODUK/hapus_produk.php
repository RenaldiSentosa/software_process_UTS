<?php
// PRODUK/hapus_produk.php

session_start();

require '../CONFIG/koneksi.php';

/*
|--------------------------------------------------------------------------
| Proteksi Admin
|--------------------------------------------------------------------------
*/

if ($_SESSION['role'] !== 'Admin') {
    die("<script>alert('Akses ditolak!'); window.location='data_produk.php';</script>");
}

/*
|--------------------------------------------------------------------------
| Ambil ID Produk
|--------------------------------------------------------------------------
*/

if (!isset($_GET['id'])) {
    die("<script>alert('ID produk tidak ditemukan!'); window.location='data_produk.php';</script>");
}

$id = $_GET['id'];

/*
|--------------------------------------------------------------------------
| Cek Produk
|--------------------------------------------------------------------------
*/

$produk = $pdo->prepare("
    SELECT *
    FROM m_produk
    WHERE id_produk = ?
");

$produk->execute([$id]);

$data = $produk->fetch();

if (!$data) {
    die("<script>alert('Produk tidak ditemukan!'); window.location='data_produk.php';</script>");
}

/*
|--------------------------------------------------------------------------
| Restricted Delete
|--------------------------------------------------------------------------
| Produk tidak boleh dihapus jika sudah ada
| di tabel transaksi detail
|--------------------------------------------------------------------------
*/

$cek = $pdo->prepare("
    SELECT *
    FROM t_penjualan_detail
    WHERE id_produk = ?
");

$cek->execute([$id]);

if ($cek->rowCount() > 0) {
    echo "<script>alert('Barang tidak boleh dihapus karena sudah pernah ada transaksi!'); window.location='data_produk.php';</script>";
    exit;
}

/*
|--------------------------------------------------------------------------
| Hapus Produk
|--------------------------------------------------------------------------
*/

$hapus = $pdo->prepare("
    DELETE FROM m_produk
    WHERE id_produk = ?
");

$hapus->execute([$id]);

echo "<script>alert('Produk berhasil dihapus!'); window.location='data_produk.php';</script>";
?>